<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ArtiFallow extends Model
{
    //
}
