<?php

namespace App\Http\Controllers;

use App\ArtiFallow;
use Illuminate\Http\Request;

class ArtiFallowController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ArtiFallow  $artiFallow
     * @return \Illuminate\Http\Response
     */
    public function show(ArtiFallow $artiFallow)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ArtiFallow  $artiFallow
     * @return \Illuminate\Http\Response
     */
    public function edit(ArtiFallow $artiFallow)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ArtiFallow  $artiFallow
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ArtiFallow $artiFallow)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ArtiFallow  $artiFallow
     * @return \Illuminate\Http\Response
     */
    public function destroy(ArtiFallow $artiFallow)
    {
        //
    }
}
