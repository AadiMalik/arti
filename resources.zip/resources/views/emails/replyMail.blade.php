<!DOCTYPE html>
<html>
<head>
    <title>Sabzi Mandi</title>
</head>
<body>
    <b>Hi,</b><br>
    <p>{{ $details['body'] }}</p>
   
</body>
</html>