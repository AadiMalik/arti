<?php

return [
    'test'   => 'I am testing'
];
